package com.myapps;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Betterpistons implements ModInitializer {
	public static final String MOD_ID = "betterpistons";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.

		LOGGER.info("Hello Fabric world!");
		LOGGER.info("you will end soon.");
		LOGGER.warn("you have been warned.");
		LOGGER.error("read this before its too late.");
		LOGGER.warn("do not push it.");
		LOGGER.warn("or it will be gone.");
		LOGGER.info("bye bye fabric world.");
		LOGGER.info("the mixin shall run.");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
